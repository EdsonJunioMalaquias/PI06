<template>
  <div id="app">

    <div class="container">

      <form>

        <div class="caixa">

            

          <h4>Pesquisar Paciente:</h4>
            
          <div class="row">
            <div class="input-field col s6">
              <input id="pesquisa" type="text" class="validate" placeholder="Digite o CPF" mask="'###.###.###-##'">
              <label class="active" for="pesquisa"></label>
            </div>
          </div>

          <button class="waves-effect waves-light btn-small">Buscar</button>
        
        </div>
      </form>

    </div>

  </div>
</template>

<script>

  import paciente from '../../services/paciente'
  export default{

    mounted(){
      paciente.listar().then(resposta => {
        console.log(resposta);
      })
    }
  }
</script>

<style>
.caixa{
  padding-top: 15%;
}
</style>